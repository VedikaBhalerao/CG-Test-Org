"use strict";

///////////////////////////////////////////////////////////////////////////////////////////////
//                 IMPORTANT - DO NOT MODIFY AUTO-GENERATED CODE OR COMMENTS                 //
//Parts of this file are auto-generated and modifications to those sections will be          //
//overwritten. You are allowed to modify:                                                    //
// - the tags in the jsDoc as described in the corresponding section                         //
// - the function name and its parameters                                                    //
// - the function body between the insertion ranges                                          //
//         "Add your customizing javaScript code below / above"                              //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Use the following jsDoc tags to describe the BL function. Setting these tags will
 * change the runtime behavior in the mobile app. The values specified in the tags determine
 * the name of the contract file. The filename format is “@this . @function .bl.js”.
 * For example, LoVisit.BeforeLoadAsync.bl.js
 * -> function: Name of the businessLogic function.
 * -> this: The LO, BO, or LU object that this function belongs to (and it is part of the filename).
 * -> kind: Type of object this function belongs to. Most common value is "businessobject".
 * -> async: If declared as async then the function should return a promise.
 * -> param: List of parameters the function accepts. Make sure the parameters match the function signature.
 * -> namespace: Use CORE or CUSTOM. If you are a Salesforce client or an implementation partner, always use CUSTOM to enable a seamless release upgrade.
 * -> maxRuntime: Maximum time this function is allowed to run, takes integer value in ms. If the max time is exceeded, error is logged.
 * -> returns: Type and variable name in which the return value is stored.
 *
 * ------- METHOD RELEVANT GENERATOR PARAMETERS BELOW - ADAPT WITH CAUTION -------
 * @function checkForInProgressVisit
 * @this BoCall
 * @kind businessobject
 * @async
 * @namespace CORE
 * @returns promise
 */
function checkForInProgressVisit() {
    var me = this;
    ///////////////////////////////////////////////////////////////////////////////////////////////
    //                                                                                           //
    //               Add your customizing javaScript code below.                                 //
    //                                                                                           //
    ///////////////////////////////////////////////////////////////////////////////////////////////

    var promise;
    // Determine if DSD Mode is active
    var isDSDMode = ApplicationContext.get(BLConstants.APPCTX.DSD.DSDMODE) || false;
    var isRetailExplicitStartVisit =
        me.getLuCallMeta().getIsStartVisitRqrToCheckIn() == "1";
    var shouldLimitToOneVisitInProgress =
        me.getLuCallMeta().getLimitToOneVisitInProgress() == "1";

    if (isDSDMode || !isRetailExplicitStartVisit || !shouldLimitToOneVisitInProgress) {
        promise = when.resolve("false");
    } else if(shouldLimitToOneVisitInProgress) {
        var jqueryQuery = {};
        jqueryQuery.params = [
            {
                field: "visitStatus",
                value: "InProgress",
            },
        ];
        promise = BoFactory.loadListAsync(
            "LoVisitsByVisitStatus",
            jqueryQuery
        ).then(function (inProgressVisit) {
            if (Utils.isDefined(inProgressVisit) && inProgressVisit.getAllItems().length > 0) {
                var messageCollector = new MessageCollector();
                var subject = inProgressVisit.getAllItems()[0].subject;
                var visitStartDateTime = inProgressVisit.getAllItems()[0].plannedVisitStartTime;
                var visitStartDate = Utils.convertAnsiDateTime2AnsiDate(visitStartDateTime);
                var buttonValues = {};
                buttonValues[Localization.resolve("Ok")] = "ok";
                messageCollector.add({
                    "level": "error",
                    "objectClass" : "BoCall",
                    "messageID" : "CasClbInProgressRetailVisitsAvailable",
                    "messageParams" : {
                    "subject" : subject,
                    "date" : visitStartDate
                    }
                });
                var messages = messageCollector.getMessages().join("<br>");
                return MessageBox.displayMessage(
                    Localization.resolve("MessageBox_Title_Attention"),
                    messages,
                    buttonValues
                ).then(function (result) {
                    return true;
                });
            } else {
                return false;
            }
        });
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    //                                                                                           //
    //               Add your customizing javaScript code above.                                 //
    //                                                                                           //
    ///////////////////////////////////////////////////////////////////////////////////////////////

    return promise;
}
