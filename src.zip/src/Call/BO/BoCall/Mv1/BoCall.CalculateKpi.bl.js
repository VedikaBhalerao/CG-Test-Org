"use strict";

///////////////////////////////////////////////////////////////////////////////////////////////
//                 IMPORTANT - DO NOT MODIFY AUTO-GENERATED CODE OR COMMENTS                 //
//Parts of this file are auto-generated and modifications to those sections will be          //
//overwritten. You are allowed to modify:                                                    //
// - the tags in the jsDoc as described in the corresponding section                         //
// - the function name and its parameters                                                    //
// - the function body between the insertion ranges                                          //
//         "Add your customizing javaScript code below / above"                              //
//                                                                                           //
// NOTE:                                                                                     //
// - If you have created PRE and POST functions, they will be executed in the same order     //
//   as before.                                                                              //
// - If you have created a REPLACE to override core function, only the REPLACE function will //
//   be executed. PRE and POST functions will be executed in the same order as before.       //
//                                                                                           //
// - For new customizations, you can directly modify this file. There is no need to use the  //
//   PRE, POST, and REPLACE functions.                                                       //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////


/**
 * Use the following jsDoc tags to describe the BL function. Setting these tags will
 * change the runtime behavior in the mobile app. The values specified in the tags determine
 * the name of the contract file. The filename format is “@this . @function .bl.js”.
 * For example, LoVisit.BeforeLoadAsync.bl.js
 * -> function: Name of the businessLogic function.
 * -> this: The LO, BO, or LU object that this function belongs to (and it is part of the filename).
 * -> kind: Type of object this function belongs to. Most common value is "businessobject".
 * -> async: If declared as async then the function should return a promise.
 * -> param: List of parameters the function accepts. Make sure the parameters match the function signature.
 * -> module: Use CORE or CUSTOM. If you are a Salesforce client or an implementation partner, always use CUSTOM to enable a seamless release upgrade.
 * -> maxRuntime: Maximum time this function is allowed to run, takes integer value in ms. If the max time is exceeded, error is logged.
 * -> returns: Type and variable name in which the return value is stored.
 * @function calculateKpi
 * @this BoCall
 * @kind businessobject
 * @async
 * @namespace CORE
 * @returns promise
 * @description This function is calculation Distribution Rate and OOS Rate for visits
 *  It also set a Distribution Issue and a OOS Issue flag on customer level
 */
function calculateKpi(){
    var me = this;
    ///////////////////////////////////////////////////////////////////////////////////////////////
    //                                                                                           //
    //               Add your customizing javaScript code below.                                 //
    //                                                                                           //
    ///////////////////////////////////////////////////////////////////////////////////////////////
    
var promise = when.resolve();

var setAccountExtensionKPIs = function(){
  promise = BoFactory.loadObjectByParamsAsync("BoCustomer", me.getQueryBy('pKey', me.getBpaMainPKey()))
    .then(function(boCustomer){
    boCustomer.setAccountDi(me.getDistributionIssue());
    boCustomer.setAccountOi(me.getOutOfStockIssue());
    return boCustomer.saveAsync();
  });
};

var calculate = function(totalSurveyProducts, surveys){
  var distributionRate = 0;
  var oosRate = 0;
  var notDistributedProducts = 0;
  var outOfStockProducts = 0;

  surveys.forEach(function(survey){
    if(survey.getValue() == "NotDistributed"){
      //number of products for current call with Call job value as 'Not Distributed'
      notDistributedProducts++;
    } else if(survey.getValue() == "OutOfStock"){
      //number of products for current call with Call job value as 'Out of Stock'
      outOfStockProducts++;
    }
  });

  if(totalSurveyProducts > 0){
    distributionRate = (totalSurveyProducts - notDistributedProducts)/ totalSurveyProducts;
    oosRate = outOfStockProducts/totalSurveyProducts;

    distributionRate = (Utils.round(distributionRate, 4, 1))*100;
    oosRate = (Utils.round(oosRate, 4, 1))*100;

    var dIssue = (distributionRate <= 92) ? "1" : "0";
    var oIssue = (oosRate > 12) ? "1" : "0";

    //Set All calculated values to call fields here.
    me.setDistributionRate(parseFloat(distributionRate.toFixed(2)));
    me.setDistributionIssue(dIssue);
    me.setOutOfStockRate(parseFloat(oosRate.toFixed(2)));
    me.setOutOfStockIssue(oIssue);
  }
};


if(Utils.isDefined(me.getBoJobManager().getLoJobDefinitions())){
  var totalSurveyProducts;
  var surveys;
  var jobDefsWithSavePresetting = me.getBoJobManager().getLoJobDefinitions().getItemsByParamArray([
    {"savePresetting" : "1", "op" : "EQ"},
    {"jobMetaId" : "Survey", "op" : "EQ"},
    {"toggleId" : "PrdDistributed", "op" : "EQ"},
    {"presetting" : "None", "op" : "NE"}
  ]);
  var isCallCompletion = me.isCallCompletion();

  //### PLANNED ###/
  if(me.getClbStatus() == BLConstants.VISIT.STATUS_PLANNED || me.getClbStatus() == BLConstants.VISIT.STATUS_INPROGRESS) {
    //Take data from LoCurrentSurvey
    if(Utils.isDefined(me.getBoJobManager().getLoCurrentSurveyProducts())){
      totalSurveyProducts = me.getBoJobManager().getLoCurrentSurveyProducts().getAllItems().length;

      if (Utils.isDefined(me.getBoJobManager().getLoCurrentSurveys())){
        surveys = me.getBoJobManager().getLoCurrentSurveys().getAllItems().filter(function(i){
          return i.hide != "1";
        });
        calculate(totalSurveyProducts, surveys);
      }
    }
  }
  //### COMPLETION AND SAVE PRESETTING JOBS ###/
  else if((isCallCompletion) && (jobDefsWithSavePresetting.length > 0)){

    //Take data from LoPos --> Surveys are only supported on Store level hence posId must be blank
    var loCurrentPOS = me.getBoJobManager().getLoPOS().getItemsByParam({"posId" : " "});

    if(Utils.isDefined(loCurrentPOS)){
      var liCurrentPOS = loCurrentPOS[0];
      totalSurveyProducts = liCurrentPOS.getSurveyCount();

      if(Utils.isDefined(liCurrentPOS.getSurveys())){
        surveys = liCurrentPOS.getSurveys().getAllItems().filter(function(i){
          return i.hide != "1";
        });
        calculate(totalSurveyProducts, surveys);
        setAccountExtensionKPIs();
      }
    }
  }
   //### COMPLETION ###/
  else if(isCallCompletion){
    setAccountExtensionKPIs();
  }
}

    ///////////////////////////////////////////////////////////////////////////////////////////////
    //                                                                                           //
    //               Add your customizing javaScript code above.                                 //
    //                                                                                           //
    ///////////////////////////////////////////////////////////////////////////////////////////////

    return promise;
}