"use strict";

///////////////////////////////////////////////////////////////////////////////////////////////
//                 IMPORTANT - DO NOT MODIFY AUTO-GENERATED CODE OR COMMENTS                 //
//Parts of this file are auto-generated and modifications to those sections will be          //
//overwritten. You are allowed to modify:                                                    //
// - the tags in the jsDoc as described in the corresponding section                         //
// - the function name and its parameters                                                    //
// - the function body between the insertion ranges                                          //
//         "Add your customizing javaScript code below / above"                              //
//                                                                                           //
// NOTE:                                                                                     //
// - If you have created PRE and POST functions, they will be executed in the same order     //
//   as before.                                                                              //
// - If you have created a REPLACE to override core function, only the REPLACE function will //
//   be executed. PRE and POST functions will be executed in the same order as before.       //
//                                                                                           //
// - For new customizations, you can directly modify this file. There is no need to use the  //
//   PRE, POST, and REPLACE functions.                                                       //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Use the following jsDoc tags to describe the BL function. Setting these tags will
 * change the runtime behavior in the mobile app. The values specified in the tags determine
 * the name of the contract file. The filename format is “@this . @function .bl.js”.
 * For example, LoVisit.BeforeLoadAsync.bl.js
 * -> function: Name of the businessLogic function.
 * -> this: The LO, BO, or LU object that this function belongs to (and it is part of the filename).
 * -> kind: Type of object this function belongs to. Most common value is "businessobject".
 * -> async: If declared as async then the function should return a promise.
 * -> param: List of parameters the function accepts. Make sure the parameters match the function signature.
 * -> module: Use CORE or CUSTOM. If you are a Salesforce client or an implementation partner, always use CUSTOM to enable a seamless release upgrade.
 * -> maxRuntime: Maximum time this function is allowed to run, takes integer value in ms. If the max time is exceeded, error is logged.
 * -> returns: Type and variable name in which the return value is stored.
 * @function deleteAdditionalWaypoints
 * @this LoCustomerOverview
 * @kind listobject
 * @namespace CORE
 * @param {Object} overviewList
 * @param {String} makePinVisible
 * @returns me
 */
function deleteAdditionalWaypoints(overviewList, makePinVisible){
    var me = this;
    ///////////////////////////////////////////////////////////////////////////////////////////////
    //                                                                                           //
    //               Add your customizing javaScript code below.                                 //
    //                                                                                           //
    ///////////////////////////////////////////////////////////////////////////////////////////////
    
if(Utils.isDefined(makePinVisible) && makePinVisible == "1"){
  var inVisiblePins = me.getItemsByParam({ "visibleInMap": "0" });
  inVisiblePins.forEach(function(inVisiblePin) {
    inVisiblePin.setVisibleInMap("1"); //Make Purple Pins Visible on date change/call cancel/del/complete.
  });
}
var filterPlannedVisits = false;
filterPlannedVisits = ApplicationContext.get('filterPlannedVisits');
overviewList.getAllItems().forEach(function (visit) {
  var visitPin = me.getItemByPKey(visit.bpaMainPKey);
  if (filterPlannedVisits && !Utils.isDefined(visitPin)) {
    visit.setVisibleInMap("0"); //Remove visibility of Purple Pins if there is a corresponding call Planned already.
  } else if(!filterPlannedVisits && Utils.isDefined(visit.getMapPinId())) {
    visit.setVisibleInMap("1");
  }
});


    ///////////////////////////////////////////////////////////////////////////////////////////////
    //                                                                                           //
    //               Add your customizing javaScript code above.                                 //
    //                                                                                           //
    ///////////////////////////////////////////////////////////////////////////////////////////////

    return me;
}