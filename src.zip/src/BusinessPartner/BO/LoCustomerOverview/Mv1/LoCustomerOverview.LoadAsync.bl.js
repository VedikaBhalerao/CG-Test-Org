"use strict";

///////////////////////////////////////////////////////////////////////////////////////////////
//                 IMPORTANT - DO NOT MODIFY AUTO-GENERATED CODE OR COMMENTS                 //
//Parts of this file are auto-generated and modifications to those sections will be          //
//overwritten. You are allowed to modify:                                                    //
// - the tags in the jsDoc as described in the corresponding section                         //
// - the function name and its parameters                                                    //
// - the function body between the insertion ranges                                          //
//         "Add your customizing javaScript code below / above"                              //
//                                                                                           //
// NOTE:                                                                                     //
// - If you have created PRE and POST functions, they will be executed in the same order     //
//   as before.                                                                              //
// - If you have created a REPLACE to override core function, only the REPLACE function will //
//   be executed. PRE and POST functions will be executed in the same order as before.       //
//                                                                                           //
// - For new customizations, you can directly modify this file. There is no need to use the  //
//   PRE, POST, and REPLACE functions.                                                       //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////

/**
 * Use the following jsDoc tags to describe the BL function. Setting these tags will
 * change the runtime behavior in the mobile app. The values specified in the tags determine
 * the name of the contract file. The filename format is “@this . @function .bl.js”.
 * For example, LoVisit.BeforeLoadAsync.bl.js
 * -> function: Name of the businessLogic function.
 * -> this: The LO, BO, or LU object that this function belongs to (and it is part of the filename).
 * -> kind: Type of object this function belongs to. Most common value is "businessobject".
 * -> async: If declared as async then the function should return a promise.
 * -> param: List of parameters the function accepts. Make sure the parameters match the function signature.
 * -> module: Use CORE or CUSTOM. If you are a Salesforce client or an implementation partner, always use CUSTOM to enable a seamless release upgrade.
 * -> maxRuntime: Maximum time this function is allowed to run, takes integer value in ms. If the max time is exceeded, error is logged.
 * -> returns: Type and variable name in which the return value is stored.
 * @function loadAsync
 * @this LoCustomerOverview
 * @kind TODO_ADD_BUSINESS_OBJECT_TYPE
 * @async
 * @namespace CORE
 * @param {Object} jsonParams
 * @returns promise
 */
function loadAsync(jsonParams){
    var me = this;
    ///////////////////////////////////////////////////////////////////////////////////////////////
    //                                                                                           //
    //               Add your customizing javaScript code below.                                 //
    //                                                                                           //
    ///////////////////////////////////////////////////////////////////////////////////////////////
    
var promise;
var newParams;

if (Utils.isOldParamsFormat(jsonParams)) {
  newParams = Utils.convertDsParamsOldToNew(jsonParams);
} 
else {
  newParams = jsonParams || {};
}
//Advanced Search Paging
if (!Utils.isDefined(newParams.asoName)) {
  newParams.asoName = 'AsoCustomerOverview';
  //Transforming back in the new Format
  jsonParams = Utils.convertDsParamsNewToOld(newParams);
}
if (Utils.isDefined(newParams.cardOverdue)) {
  newParams.addCond_OverdueCustomers = " AND customers.isOverdue = '1' " ;
  newParams.asoName = 'AsoOverdueCustomerOverview';
}

if (Utils.isDefined(newParams.asoName) && newParams.asoName == 'AsoFindCustomers') {
  if(Utils.isDefined(newParams.plannedVisits) && newParams.plannedVisits == 1) {
    ApplicationContext.set('filterPlannedVisits', true);
  } else {
    ApplicationContext.set('filterPlannedVisits', false);
  }
}

// Additional condition for the case that lead time / follow up time of a substitution is considered
if (newParams.considerSubstitutionLeadFollowUpTime == '1') {
  newParams.addCond_LeadTimeFollowUpTime = " ((SubBpaRelValidFrom <= #TodayAsDate# AND SubBpaRelValidThru >= #TodayAsDate#) OR Account_Manager__c.Id IS NOT NULL ) AND ";
}

promise = BoFactory.loadObjectByParamsAsync("LuCurrentAddress", {}).then(
  function(luCurrentAddress){
    jsonParams.params.push({ "field": "currentLatitude", "value": luCurrentAddress.latitude });
    jsonParams.params.push({ "field": "currentLongitude", "value": luCurrentAddress.longitude });
    return me.addAsoInformation(jsonParams);
  }).then(
  function (success) {
    return Facade.getListAsync(LO_CUSTOMEROVERVIEW, jsonParams);
  }).then(
  function (items) {
    items.forEach(function(item){
      item.mapIcon = 'PurpleGoogleMarkerEmpty';
      item.visibleInMap = "1";
    });
    me.addItems(items, jsonParams);
    if(items.length > 0) {
      me.setCurrentByPKey(items[0].getPKey());
    }
    return me;
  });

    ///////////////////////////////////////////////////////////////////////////////////////////////
    //                                                                                           //
    //               Add your customizing javaScript code above.                                 //
    //                                                                                           //
    ///////////////////////////////////////////////////////////////////////////////////////////////

    return promise;
}